package com.example.demo.service.impl;

import com.example.demo.service.DemoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Service实现类
 *
 * @author renpl 2019-11-03
 */
@Slf4j
public class DemoServiceImpl implements DemoService {


    @Override
    public void business(String str) {
        log.info("执行了业务逻辑，接口参数：[{}}", str);
    }
}
