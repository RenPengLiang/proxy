package com.example.demo.proxy;

import com.example.demo.service.impl.DemoServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;

/**
 * Service CGLIB动态代理类
 * CGLIB：Java字节码操控框架，它能被用来动态生成类或者增强已有类的功能
 * CGLIB生成动态代理类
 *   优点是：目标对象不用实现接口，采用fastClass机制比JDK动态代理执行快
 *   缺点是：被final修饰的目标对象就无法进行代理，需要第三方jar
 *
 * @author renpl 2019-11-03
 */
@Slf4j
public class DemoServiceInterceptor<T> implements MethodInterceptor {

    private T target;

    public DemoServiceInterceptor(T target) {
        this.target = target;
    }

    public T create() {
        Enhancer enhancer = new Enhancer();
        enhancer.setSuperclass(this.target.getClass());
        enhancer.setCallback(this);
        return (T) enhancer.create();
    }

    @Override
    public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
        log.info("Cglib动态代理接口中执行：非业务相关的代码");
        Object result = methodProxy.invokeSuper(o, objects);
        return result;
    }

    public static void main(String[] args) {
        DemoServiceInterceptor<DemoServiceImpl> proxy = new DemoServiceInterceptor<>(new DemoServiceImpl());
        DemoServiceImpl target = proxy.create();
        target.business("前端传入参数");
    }
}
