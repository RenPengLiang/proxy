package com.example.demo.service;

/**
 * Service
 *
 * @author renpl 2019-11-03
 */
public interface DemoService {

    /**
     * 执行业务逻辑的方法
     * @param str
     */
    void business(String str) throws Exception;
}
