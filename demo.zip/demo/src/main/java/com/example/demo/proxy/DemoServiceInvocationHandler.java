package com.example.demo.proxy;

import com.example.demo.service.DemoService;
import com.example.demo.service.impl.DemoServiceImpl;
import lombok.extern.slf4j.Slf4j;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * Service JDK动态代理类
 *   优点：只需要编写一次，就可以代理不同的目标对象了
 *   缺点：目标对象必须实现接口，否则将无法进行代理
 * 关键类以及接口：
 * Proxy：
 *   所有动态代理类的父类，提供一系列的静态方法来创建动态代理类
 * InvocationHandler：
 *   每个动态代理类都必须实现InvocationHandler接口，并且每个代理类的实例都关联到一个handler
 *   ，当我们通过代理对象调用一个方法时，会通过handler转发给目标对象对应的方法
 *
 * @author renpl 2019-11-03
 */
@Slf4j
public class DemoServiceInvocationHandler<T> implements InvocationHandler {

    private T target;

    public DemoServiceInvocationHandler(T target) {
        this.target = target;
    }

    /**
     * 使用JDK自带的包创建动态代理类实例
     *
     * @return
     */
    public T createProxy() {
        Object proxy = Proxy.newProxyInstance(target.getClass().getClassLoader(), target.getClass().getInterfaces(), this);
        return (T) proxy;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        log.info("静态代理接口中执行：非业务相关的代码");
        Object result = method.invoke(proxy, args);
        return result;
    }

    public static void main(String[] args) throws Exception {
        DemoServiceInvocationHandler<DemoService> proxy = new DemoServiceInvocationHandler<>(new DemoServiceImpl());
        DemoService demoService = proxy.createProxy();
        demoService.business("前端传入参数");
    }

}
