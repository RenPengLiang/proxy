package com.example.demo.proxy;

import com.example.demo.service.DemoService;
import com.example.demo.service.impl.DemoServiceImpl;
import lombok.extern.slf4j.Slf4j;

/**
 * Service静态代理类
 *
 * @author renpl 2019-11-03
 */
@Slf4j
public class DemoServiceStaticProxy implements DemoService {

    private DemoService target;

    /**
     * 通过静态代理的构造方法将DemoService实现类注入进去
     * 什么是代理模式？
     *   是指具有与被代理对象相同接口的类，客户端通过访问代理类接口就可以间接的访问到被代理对象接口，代理对象
     *   可以在目标对象和客户端之间起动中介和保护目标对象的作用，可扩展性强
     * 代理类作用：
     *   1.扩展：扩展被代理对象接口功能
     *   2.转发：转发到被代理对象接口中
     * @param demoService
     */
    public DemoServiceStaticProxy(DemoService demoService){
        this.target = demoService;
    }

    @Override
    public void business(String str) throws Exception {
      log.info("JDK动态代理接口中执行：非业务相关的代码");
      // 执行回调方法-执行目标对象中的方法
      this.target.business(str);
    }

    public static void main(String[] args) throws Exception {
        DemoServiceStaticProxy proxy = new DemoServiceStaticProxy(new DemoServiceImpl());
        proxy.business("前端传入参数");
    }
}
